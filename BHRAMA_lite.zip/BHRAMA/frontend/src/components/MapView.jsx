import React, { useEffect, useRef, useState, useCallback } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { getGibsTileUrl, GIBS_LAYERS } from '../services/gibsLayers';
import { searchLocation } from '../services/geocoding';

// Styling for the selected area
const SELECTION_STYLE = {
  color: '#FF6B35',
  weight: 2,
  opacity: 0.9,
  fillColor: '#FF6B35',
  fillOpacity: 0.22,
  dashArray: null
};

const PREVIEW_STYLE = {
  color: '#FF6B35',
  weight: 2,
  opacity: 0.7,
  fillColor: '#FF6B35',
  fillOpacity: 0.12,
  dashArray: '5, 5'
};

// Geodesic area calculation helper
function calculatePolygonArea(latlngs) {
  if (!latlngs || latlngs.length < 3) return 0;
  const R = 6378.137; // Earth radius in km
  let total = 0;
  for (let i = 0; i < latlngs.length; i++) {
    const p1 = latlngs[i];
    const p2 = latlngs[(i + 1) % latlngs.length];
    const rad = Math.PI / 180;
    total += (p2.lng - p1.lng) * rad * (2 + Math.sin(p1.lat * rad) + Math.sin(p2.lat * rad));
  }
  return Math.abs((total * R * R) / 2);
}

function calculateRectangleArea(bounds) {
  const sw = bounds.getSouthWest();
  const ne = bounds.getNorthEast();
  const midLat = (sw.lat + ne.lat) / 2;
  const rad = Math.PI / 180;
  const widthKm = Math.abs(ne.lng - sw.lng) * 111.32 * Math.cos(midLat * rad);
  const heightKm = Math.abs(ne.lat - sw.lat) * 110.574;
  return widthKm * heightKm;
}

export default function MapView({
  theme = 'dark',
  selectedLayerId,
  selectedDate,
  opacity,
  drawMode,
  onSetDrawMode,
  pointRadiusKm,
  selectedArea,
  onSelectArea,
  onClearArea,
  onAnalyseArea,
  validationError,
  isAnalyzing
}) {
  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);
  const baseTileLayerRef = useRef(null);
  const gibsTileLayerRef = useRef(null);
  const activeLayerRef = useRef(null);
  const previewLayerRef = useRef(null);

  // Drawing state refs
  const drawStateRef = useRef({
    startLatLng: null,
    points: []
  });

  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [geoNotice, setGeoNotice] = useState(null);
  const [showKeyWarning, setShowKeyWarning] = useState(!import.meta.env.VITE_MAPTILER_KEY);

  // 1. Initialize Map
  useEffect(() => {
    if (mapRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: [20, 0],
      zoom: 3,
      minZoom: 2,
      maxZoom: 18,
      zoomControl: false
    });

    // Zoom controls on top right
    L.control.zoom({ position: 'topright' }).addTo(map);

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // 1b. Basemap Tile Layer (Updates dynamically when theme toggles)
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (baseTileLayerRef.current) {
      map.removeLayer(baseTileLayerRef.current);
      baseTileLayerRef.current = null;
    }

    const mapTilerKey = import.meta.env.VITE_MAPTILER_KEY;
    const styleId = theme === 'light' ? 'dataviz-light' : 'dataviz-dark';

    if (mapTilerKey) {
      const baseLayer = L.tileLayer(`https://api.maptiler.com/maps/${styleId}/{z}/{x}/{y}.png?key=${mapTilerKey}`, {
        tileSize: 512,
        zoomOffset: -1,
        minZoom: 0,
        maxZoom: 22,
        attribution: '&copy; <a href="https://www.maptiler.com/copyright/" target="_blank" rel="noopener noreferrer">MapTiler</a> &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>',
        crossOrigin: true
      });
      baseLayer.addTo(map);
      baseTileLayerRef.current = baseLayer;
    } else {
      // Fallback to OpenStreetMap if key is not provided
      const baseLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>',
        maxZoom: 19
      });
      baseLayer.addTo(map);
      baseTileLayerRef.current = baseLayer;
    }
  }, [theme]);

  // 2. Update NASA GIBS Tile Layer
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (gibsTileLayerRef.current) {
      map.removeLayer(gibsTileLayerRef.current);
      gibsTileLayerRef.current = null;
    }

    if (selectedLayerId) {
      const tileUrl = getGibsTileUrl(selectedLayerId, selectedDate);
      const activeLayer = GIBS_LAYERS.find(l => l.id === selectedLayerId);
      const maxNativeZoom = activeLayer?.maxZoom || 7;

      const gibsLayer = L.tileLayer(tileUrl, {
        opacity: opacity,
        zIndex: 50,
        tileSize: 256,
        maxNativeZoom: maxNativeZoom,
        maxZoom: 19,
        attribution: '&copy; <a href="https://gibs.earthdata.nasa.gov/" target="_blank" rel="noopener noreferrer">NASA EOSDIS GIBS</a>'
      });
      gibsLayer.addTo(map);
      gibsTileLayerRef.current = gibsLayer;
    }
  }, [selectedLayerId, selectedDate]);

  // 3. Update Opacity
  useEffect(() => {
    if (gibsTileLayerRef.current) {
      gibsTileLayerRef.current.setOpacity(opacity);
    }
  }, [opacity]);

  // 4. Render Active Area Selection Layer
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (activeLayerRef.current) {
      map.removeLayer(activeLayerRef.current);
      activeLayerRef.current = null;
    }

    if (!selectedArea) return;

    let layer = null;
    if (selectedArea.type === 'Point Radius' && selectedArea.center && selectedArea.radiusKm) {
      layer = L.circle([selectedArea.center.lat, selectedArea.center.lon], {
        radius: selectedArea.radiusKm * 1000,
        ...SELECTION_STYLE
      });
    } else if (selectedArea.type === 'Rectangle' && selectedArea.bounds) {
      layer = L.rectangle(selectedArea.bounds, SELECTION_STYLE);
    } else if (selectedArea.type === 'Polygon' && selectedArea.latlngs) {
      layer = L.polygon(selectedArea.latlngs, SELECTION_STYLE);
    }

    if (layer) {
      layer.addTo(map);
      activeLayerRef.current = layer;
    }
  }, [selectedArea]);

  // 5. Drawing Event Handlers
  const handleMapClick = useCallback((e) => {
    const map = mapRef.current;
    if (!map || !drawMode) return;

    if (drawMode === 'point') {
      const lat = e.latlng.lat;
      const lon = e.latlng.lng;
      const radiusKm = pointRadiusKm;
      const areaKm2 = Math.round(Math.PI * radiusKm * radiusKm);

      onSelectArea({
        type: 'Point Radius',
        center: { lat, lon },
        radiusKm: radiusKm,
        areaKm2: areaKm2
      });
      onSetDrawMode(null);
    } else if (drawMode === 'rectangle') {
      if (!drawStateRef.current.startLatLng) {
        // First corner
        drawStateRef.current.startLatLng = e.latlng;
      } else {
        // Second corner (finish)
        const bounds = L.latLngBounds(drawStateRef.current.startLatLng, e.latlng);
        const area = Math.round(calculateRectangleArea(bounds));
        const center = bounds.getCenter();

        if (previewLayerRef.current) {
          map.removeLayer(previewLayerRef.current);
          previewLayerRef.current = null;
        }

        onSelectArea({
          type: 'Rectangle',
          bounds: bounds,
          center: { lat: center.lat, lon: center.lng },
          areaKm2: area
        });

        drawStateRef.current.startLatLng = null;
        onSetDrawMode(null);
      }
    } else if (drawMode === 'polygon') {
      const points = drawStateRef.current.points;
      
      // Check if user clicked close to the first point to close polygon
      if (points.length >= 2) {
        const first = points[0];
        const dist = map.distance(first, e.latlng);
        if (dist < 30000 || points.length >= 12) { // 30km tolerance or max points
          const area = Math.round(calculatePolygonArea(points));
          const poly = L.polygon(points);
          const center = poly.getBounds().getCenter();

          if (previewLayerRef.current) {
            map.removeLayer(previewLayerRef.current);
            previewLayerRef.current = null;
          }

          onSelectArea({
            type: 'Polygon',
            latlngs: points,
            center: { lat: center.lat, lon: center.lng },
            areaKm2: area
          });

          drawStateRef.current.points = [];
          onSetDrawMode(null);
          return;
        }
      }

      points.push(e.latlng);
      
      // Update preview
      if (previewLayerRef.current) {
        map.removeLayer(previewLayerRef.current);
      }
      previewLayerRef.current = L.polyline(points, PREVIEW_STYLE).addTo(map);
    }
  }, [drawMode, pointRadiusKm, onSelectArea, onSetDrawMode]);

  const handleMouseMove = useCallback((e) => {
    const map = mapRef.current;
    if (!map || !drawMode) return;

    if (drawMode === 'rectangle' && drawStateRef.current.startLatLng) {
      const bounds = L.latLngBounds(drawStateRef.current.startLatLng, e.latlng);
      if (previewLayerRef.current) {
        map.removeLayer(previewLayerRef.current);
      }
      previewLayerRef.current = L.rectangle(bounds, PREVIEW_STYLE).addTo(map);
    }
  }, [drawMode]);

  // Bind/unbind map listeners
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    map.on('click', handleMapClick);
    map.on('mousemove', handleMouseMove);

    return () => {
      map.off('click', handleMapClick);
      map.off('mousemove', handleMouseMove);
    };
  }, [handleMapClick, handleMouseMove]);

  // Clear preview when mode is cancelled
  useEffect(() => {
    if (!drawMode && previewLayerRef.current && mapRef.current) {
      mapRef.current.removeLayer(previewLayerRef.current);
      previewLayerRef.current = null;
      drawStateRef.current = { startLatLng: null, points: [] };
    }
  }, [drawMode]);

  // 6. Geocoding Search
  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    const results = await searchLocation(searchQuery);
    setSearchResults(results);
    setIsSearching(false);
  };

  const handleSelectSearchResult = (item) => {
    if (!mapRef.current) return;
    mapRef.current.flyTo([item.lat, item.lon], 9, { duration: 1.5 });
    setSearchResults([]);
    setSearchQuery(item.name.split(',')[0]);
  };

  // 7. Use My Location
  const handleUseMyLocation = () => {
    if (!navigator.geolocation) {
      setGeoNotice('Geolocation is not supported by your browser.');
      setTimeout(() => setGeoNotice(null), 4000);
      return;
    }

    setGeoNotice('Detecting coordinates...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        if (mapRef.current) {
          mapRef.current.flyTo([latitude, longitude], 10, { duration: 1.5 });
          setGeoNotice('Centered on your location.');
          setTimeout(() => setGeoNotice(null), 3000);
        }
      },
      (err) => {
        setGeoNotice('Could not retrieve location. Permission denied or unavailable.');
        setTimeout(() => setGeoNotice(null), 4000);
      },
      { timeout: 8000 }
    );
  };

  return (
    <div className="map-container">
      {/* Search Bar & My Location Floating Header */}
      <div className="map-top-bar">
        <form onSubmit={handleSearch} className="search-box-container">
          <span className="search-icon" aria-hidden="true">🔍</span>
          <input 
            type="text"
            className="search-input"
            placeholder="Search worldwide (e.g. Amazon Basin, Tokyo)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            aria-label="Search places worldwide using Nominatim geocoding"
          />
          {searchQuery && (
            <button 
              type="button" 
              className="search-clear" 
              onClick={() => { setSearchQuery(''); setSearchResults([]); }}
              aria-label="Clear search query"
            >
              ✕
            </button>
          )}

          {searchResults.length > 0 && (
            <div className="search-results-dropdown" role="listbox">
              {searchResults.map((r, i) => (
                <div 
                  key={i} 
                  className="search-result-item" 
                  onClick={() => handleSelectSearchResult(r)}
                  role="option"
                  aria-selected="false"
                  tabIndex={0}
                >
                  {r.name}
                </div>
              ))}
            </div>
          )}
        </form>

        <button 
          className="btn btn-outline" 
          onClick={handleUseMyLocation}
          title="Jump to current GPS location"
          style={{ height: '40px', backgroundColor: 'rgba(21, 28, 59, 0.95)' }}
          aria-label="Use my device location"
        >
          <span>🎯</span> Location
        </button>

        {geoNotice && (
          <span style={{ 
            fontSize: '11px', 
            background: 'rgba(11, 16, 38, 0.9)', 
            padding: '6px 12px', 
            borderRadius: '4px',
            border: '1px solid var(--surface-border)',
            color: 'var(--accent)'
          }}>
            {geoNotice}
          </span>
        )}
      </div>

      {/* Friendly Notification when MapTiler Key is Missing */}
      {!import.meta.env.VITE_MAPTILER_KEY && showKeyWarning && (
        <div style={{
          position: 'absolute',
          top: '68px',
          left: '16px',
          zIndex: 600,
          backgroundColor: 'rgba(21, 28, 59, 0.96)',
          border: '1px solid var(--accent)',
          borderRadius: '8px',
          padding: '10px 14px',
          boxShadow: 'var(--shadow-lg)',
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          fontSize: '12px',
          maxWidth: '460px',
          backdropFilter: 'blur(6px)'
        }} role="alert">
          <span style={{ fontSize: '18px' }}>🗺️</span>
          <div style={{ flex: 1, color: 'var(--text)' }}>
            <strong>MapTiler Key Missing:</strong> To view the high-contrast <code>dataviz-dark</code> basemap, please add <code>VITE_MAPTILER_KEY</code> in your <code>frontend/.env</code> file and restart the server.
          </div>
          <button 
            className="btn btn-ghost" 
            style={{ padding: '2px 6px', fontSize: '12px', color: 'var(--text-muted)' }}
            onClick={() => setShowKeyWarning(false)}
            aria-label="Dismiss key warning"
          >
            ✕
          </button>
        </div>
      )}

      {/* Map DOM Element */}
      <div ref={mapContainerRef} className="leaflet-map" />

      {/* Floating Active Layer Color Legend */}
      {(() => {
        const activeGibs = GIBS_LAYERS.find(l => l.id === selectedLayerId);
        if (!activeGibs) return null;
        return (
          <div style={{
            position: 'absolute',
            bottom: '24px',
            right: '16px',
            zIndex: 400,
            backgroundColor: 'rgba(21, 28, 59, 0.94)',
            border: '1px solid var(--surface-border)',
            borderRadius: '8px',
            padding: '8px 12px',
            boxShadow: 'var(--shadow-md)',
            backdropFilter: 'blur(8px)',
            minWidth: '220px',
            pointerEvents: 'none'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px', fontWeight: 600, color: 'var(--text)', marginBottom: '5px' }}>
              <span>{activeGibs.icon}</span>
              <span>{activeGibs.name}</span>
            </div>
            {activeGibs.gradient && (
              <>
                <div style={{
                  height: '6px',
                  borderRadius: '3px',
                  background: activeGibs.gradient,
                  marginBottom: '4px'
                }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '9px', color: 'var(--text-muted)' }}>
                  <span>{activeGibs.legendMin}</span>
                  <span>{activeGibs.legendMax}</span>
                </div>
              </>
            )}
          </div>
        );
      })()}

      {/* Floating Active Selection Badge (Bottom Left) */}
      {selectedArea && (
        <div className="selection-status-badge">
          <div className="selection-info">
            <span className="selection-title">Selected Region ({selectedArea.type})</span>
            <span className="selection-details">
              Area: {selectedArea.areaKm2.toLocaleString()} km²
            </span>
            <span className="selection-coords">
              Lat: {selectedArea.center.lat.toFixed(3)}°, Lon: {selectedArea.center.lon.toFixed(3)}°
            </span>
          </div>

          <div style={{ display: 'flex', gap: '8px' }}>
            <button 
              className="btn btn-outline" 
              style={{ padding: '6px 10px', fontSize: '11px' }}
              onClick={onClearArea}
              disabled={isAnalyzing}
            >
              Clear
            </button>
            <button 
              className="btn btn-accent" 
              style={{ padding: '6px 14px', fontSize: '11px' }}
              onClick={onAnalyseArea}
              disabled={isAnalyzing || !!validationError}
            >
              Analyse ➔
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
