import React from 'react';
import StatCards from './StatCards';
import ChartsView from './ChartsView';

export default function ResultsPanel({ 
  analysisData, 
  isAnalyzing, 
  selectedArea, 
  selectedLayerCategory,
  onTriggerAnalysis,
  theme = 'dark'
}) {
  return (
    <div className="panel-section" style={{ borderBottom: 'none' }}>
      <div className="panel-section-title" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span>📊 Step 3: Climate Insights &amp; Analytics</span>
        {analysisData && (
          <span className={`data-source-pill ${analysisData.isMockData ? 'mock' : 'live'}`}>
            <span className="data-dot" />
            {analysisData.isMockData ? 'Simulation Mode' : 'Live NASA Data'}
          </span>
        )}
      </div>

      {/* 1. Loading State */}
      {isAnalyzing && (
        <div style={{ padding: '24px 0', textAlign: 'center' }}>
          <div className="skeleton" style={{ height: '70px', marginBottom: '12px' }} />
          <div className="skeleton" style={{ height: '180px', marginBottom: '12px' }} />
          <div className="skeleton" style={{ height: '90px' }} />
          <p style={{ marginTop: '12px', fontSize: '12px', color: 'var(--accent)' }}>
            📡 Fetching daily satellite observations from NASA POWER API...
          </p>
        </div>
      )}

      {/* 2. Empty State (No Analysis Run Yet) */}
      {!isAnalyzing && !analysisData && (
        <div className="empty-state">
          <div className="empty-icon">🛰️</div>
          <h3>Ready for Observation Analysis</h3>
          <p>
            {selectedArea 
              ? 'Click the "Analyse area" button above to fetch NASA meteorological data for your selected region.'
              : 'Select an area on the map using a rectangle, polygon, or radius point to reveal NASA surface observations.'}
          </p>
          {selectedArea && (
            <button 
              className="btn btn-accent" 
              style={{ marginTop: '16px' }}
              onClick={onTriggerAnalysis}
            >
              Analyse Area Now ➔
            </button>
          )}
        </div>
      )}

      {/* 3. Analysis Results View */}
      {!isAnalyzing && analysisData && (
        <div>
          {/* Plain-Language Insight Box */}
          <div className="insight-box" role="region" aria-label="Plain-language Insight">
            <span className="insight-icon" aria-hidden="true">💡</span>
            <div className="insight-text">
              <h4>Regional Insight</h4>
              <p>{analysisData.insight}</p>
            </div>
          </div>

          {/* 4 Summary Stat Cards */}
          <StatCards stats={analysisData.stats} />

          {/* Time Series Line Chart & Comparison Bar Chart */}
          <ChartsView 
            timeSeries={analysisData.timeSeries} 
            comparison={analysisData.comparison}
            layerCategory={selectedLayerCategory}
            theme={theme}
          />
        </div>
      )}
    </div>
  );
}
