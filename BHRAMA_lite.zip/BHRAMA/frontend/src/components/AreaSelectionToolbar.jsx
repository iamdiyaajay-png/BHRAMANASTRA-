import React from 'react';

export default function AreaSelectionToolbar({
  drawMode,
  onSetDrawMode,
  pointRadiusKm,
  onSetPointRadiusKm,
  selectedArea,
  onClearArea,
  onAnalyseArea,
  validationError,
  isAnalyzing
}) {
  return (
    <div className="panel-section">
      <div className="panel-section-title">
        <span>📐 Step 2: Area Selection</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px', marginBottom: '10px' }}>
        <button 
          className={`tool-btn ${drawMode === 'rectangle' ? 'active' : ''}`}
          onClick={() => onSetDrawMode(drawMode === 'rectangle' ? null : 'rectangle')}
          title="Click and drag or select two corners to define a rectangle"
          aria-pressed={drawMode === 'rectangle'}
        >
          <span>⬛</span> Rectangle
        </button>

        <button 
          className={`tool-btn ${drawMode === 'polygon' ? 'active' : ''}`}
          onClick={() => onSetDrawMode(drawMode === 'polygon' ? null : 'polygon')}
          title="Click multiple points on the map to draw a custom boundary polygon"
          aria-pressed={drawMode === 'polygon'}
        >
          <span>⬡</span> Polygon
        </button>

        <button 
          className={`tool-btn ${drawMode === 'point' ? 'active' : ''}`}
          onClick={() => onSetDrawMode(drawMode === 'point' ? null : 'point')}
          title="Click a point to place a circular radius buffer"
          aria-pressed={drawMode === 'point'}
        >
          <span>📍</span> Point + R
        </button>
      </div>

      {drawMode === 'point' && (
        <div className="radius-slider-group" style={{ backgroundColor: 'var(--bg)', borderRadius: 'var(--radius-sm)', padding: '10px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text)' }}>
            <span>Radius Buffer:</span>
            <span style={{ color: 'var(--accent)', fontWeight: 600 }}>{pointRadiusKm} km</span>
          </div>
          <input 
            type="range"
            min="5"
            max="150"
            step="5"
            value={pointRadiusKm}
            onChange={(e) => onSetPointRadiusKm(parseInt(e.target.value, 10))}
            className="radius-slider"
            aria-label="Selection Point Radius in Kilometers"
          />
          <span style={{ fontSize: '10px', color: 'var(--text-muted)' }}>
            Click anywhere on the map to drop a {pointRadiusKm} km radius circle.
          </span>
        </div>
      )}

      {drawMode && (
        <div style={{ 
          fontSize: '11px', 
          color: 'var(--accent)', 
          backgroundColor: 'rgba(255, 107, 53, 0.08)', 
          padding: '8px 12px', 
          borderRadius: '4px',
          border: '1px dashed var(--accent)',
          marginTop: '8px'
        }}>
          {drawMode === 'rectangle' && '👉 Click and drag on the map to define your rectangular bounding box.'}
          {drawMode === 'polygon' && '👉 Click on the map to place vertices. Click the initial point or double-click to finish.'}
          {drawMode === 'point' && '👉 Click anywhere on the map to place your circular area.'}
        </div>
      )}

      {/* Selected Area Summary Card */}
      {selectedArea && (
        <div style={{ 
          marginTop: '12px', 
          backgroundColor: 'var(--bg)', 
          border: '1px solid var(--accent)', 
          borderRadius: 'var(--radius-sm)', 
          padding: '12px' 
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
            <span style={{ fontSize: '11px', color: 'var(--accent)', fontWeight: 700, textTransform: 'uppercase' }}>
              Active Selection
            </span>
            <span style={{ fontSize: '10px', color: 'var(--text-muted)' }}>
              Mode: {selectedArea.type}
            </span>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '4px' }}>
            <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Estimated Area:</span>
            <span style={{ fontSize: '16px', fontFamily: 'var(--font-mono)', fontWeight: 700, color: 'var(--text)' }}>
              {selectedArea.areaKm2.toLocaleString()} km²
            </span>
          </div>

          <div style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
            Center: {selectedArea.center.lat.toFixed(4)}°, {selectedArea.center.lon.toFixed(4)}°
          </div>

          {validationError && (
            <div style={{ 
              marginTop: '8px', 
              color: 'var(--danger)', 
              fontSize: '11px', 
              display: 'flex', 
              alignItems: 'center', 
              gap: '6px' 
            }} role="alert">
              <span>⚠️</span> {validationError}
            </div>
          )}

          <div style={{ display: 'flex', gap: '8px', marginTop: '12px' }}>
            <button 
              className="btn btn-outline" 
              style={{ flex: 1 }}
              onClick={onClearArea}
              disabled={isAnalyzing}
            >
              Clear
            </button>
            <button 
              className="btn btn-accent" 
              style={{ flex: 2 }}
              onClick={onAnalyseArea}
              disabled={isAnalyzing || !!validationError}
            >
              {isAnalyzing ? (
                <>
                  <span className="spinner" aria-hidden="true">⏳</span> Analyzing...
                </>
              ) : (
                'Analyse Area ➔'
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
