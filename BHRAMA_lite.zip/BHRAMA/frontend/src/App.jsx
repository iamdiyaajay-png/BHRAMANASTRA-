import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import MapView from './components/MapView';
import LayerControls from './components/LayerControls';
import AreaSelectionToolbar from './components/AreaSelectionToolbar';
import ResultsPanel from './components/ResultsPanel';
import TourModal from './components/TourModal';
import { GIBS_LAYERS, getDefaultGibsDate } from './services/gibsLayers';
import { fetchNasaPowerData } from './services/nasaPowerApi';

export default function App() {
  // 0. Theme Mode (Dark / Light)
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('bhramanasthra_theme') || 'dark';
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('bhramanasthra_theme', theme);
  }, [theme]);

  const handleToggleTheme = () => {
    setTheme(t => (t === 'dark' ? 'light' : 'dark'));
  };

  // 1. Layer & Date State (Step 1)
  const [selectedLayerId, setSelectedLayerId] = useState('MODIS_Terra_Land_Surface_Temp_Day');
  const [selectedDate, setSelectedDate] = useState(getDefaultGibsDate());
  const [opacity, setOpacity] = useState(0.75);

  // 2. Area Selection State (Step 2)
  const [drawMode, setDrawMode] = useState(null);
  const [pointRadiusKm, setPointRadiusKm] = useState(25);
  const [selectedArea, setSelectedArea] = useState(null);
  const [validationError, setValidationError] = useState(null);

  // 3. Analytics & Results State (Step 3)
  const [analysisData, setAnalysisData] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // 4. UI Shell State
  const [isPanelOpen, setIsPanelOpen] = useState(true);
  const [isTourOpen, setIsTourOpen] = useState(false);

  // Determine current workflow step
  let currentStep = 1;
  if (analysisData) {
    currentStep = 3;
  } else if (selectedArea) {
    currentStep = 2;
  }

  // Active layer object
  const activeLayer = GIBS_LAYERS.find(l => l.id === selectedLayerId) || GIBS_LAYERS[0];

  // Handler for new area selection
  const handleSelectArea = (area) => {
    // Validate selection bounds (medium validation)
    let error = null;
    if (area.areaKm2 < 1) {
      error = 'Selected area is too small (< 1 km²). Please select a slightly larger region for reliable satellite coverage.';
    } else if (area.areaKm2 > 2000000) {
      error = 'Selected area is too large (> 2,000,000 km²). Please zoom in to analyze regional climate patterns.';
    }

    setSelectedArea(area);
    setValidationError(error);
    setAnalysisData(null); // Reset prior analysis on new selection
    setIsPanelOpen(true);  // Ensure panel is visible
  };

  const handleClearArea = () => {
    setSelectedArea(null);
    setValidationError(null);
    setAnalysisData(null);
    setDrawMode(null);
  };

  // Handler for "Analyse Area" trigger
  const handleAnalyseArea = async () => {
    if (!selectedArea || validationError) return;

    setIsAnalyzing(true);
    setIsPanelOpen(true);

    try {
      const data = await fetchNasaPowerData(
        selectedArea.center.lat,
        selectedArea.center.lon,
        activeLayer.category
      );
      setAnalysisData(data);
    } catch (err) {
      console.error('Error in analysis workflow:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="app-layout">
      {/* 1. Header Bar */}
      <Header 
        currentStep={currentStep}
        onOpenTour={() => setIsTourOpen(true)}
        isPanelOpen={isPanelOpen}
        onTogglePanel={() => setIsPanelOpen(open => !open)}
        theme={theme}
        onToggleTheme={handleToggleTheme}
      />

      {/* 2. Main Workspace */}
      <div className="workspace-container">
        {/* Full Screen Interactive Map */}
        <MapView 
          theme={theme}
          selectedLayerId={selectedLayerId}
          selectedDate={selectedDate}
          opacity={opacity}
          drawMode={drawMode}
          onSetDrawMode={setDrawMode}
          pointRadiusKm={pointRadiusKm}
          selectedArea={selectedArea}
          onSelectArea={handleSelectArea}
          onClearArea={handleClearArea}
          onAnalyseArea={handleAnalyseArea}
          validationError={validationError}
          isAnalyzing={isAnalyzing}
        />

        {/* Collapsible Control & Results Side Panel */}
        <aside 
          className={`side-panel ${!isPanelOpen ? 'collapsed' : ''}`}
          aria-label="Satellite Controls and Analysis Dashboard"
        >
          <div className="panel-header">
            <h2>
              <span>🛰️</span> Earth Observation Panel
            </h2>
            <button 
              className="btn btn-ghost" 
              style={{ padding: '4px 8px' }}
              onClick={() => setIsPanelOpen(false)}
              aria-label="Close side panel"
            >
              ✕
            </button>
          </div>

          {/* Step 1: Satellite Layer & Date Selection */}
          <LayerControls 
            selectedLayerId={selectedLayerId}
            onSelectLayer={setSelectedLayerId}
            selectedDate={selectedDate}
            onDateChange={setSelectedDate}
            opacity={opacity}
            onOpacityChange={setOpacity}
          />

          {/* Step 2: Area Selection Controls */}
          <AreaSelectionToolbar 
            drawMode={drawMode}
            onSetDrawMode={setDrawMode}
            pointRadiusKm={pointRadiusKm}
            onSetPointRadiusKm={setPointRadiusKm}
            selectedArea={selectedArea}
            onClearArea={handleClearArea}
            onAnalyseArea={handleAnalyseArea}
            validationError={validationError}
            isAnalyzing={isAnalyzing}
          />

          {/* Step 3: Analysis Results, Stat Cards & Charts */}
          <ResultsPanel 
            analysisData={analysisData}
            isAnalyzing={isAnalyzing}
            selectedArea={selectedArea}
            selectedLayerCategory={activeLayer.category}
            onTriggerAnalysis={handleAnalyseArea}
            theme={theme}
          />
        </aside>
      </div>

      {/* 3. Footer Bar */}
      <Footer />

      {/* 4. Interactive First-Time Tour Modal */}
      <TourModal 
        isOpen={isTourOpen}
        onClose={() => setIsTourOpen(false)}
      />
    </div>
  );
}
