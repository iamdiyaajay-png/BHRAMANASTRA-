# Section 4: The 25 Claude Prompt Cheat Sheet Triggers

| Trigger Code | How to Use in Prompt | Execution Modifier Function |
| :--- | :--- | :--- |
| `SCAFFOLD` | `"scaffold this first"` | Outputs project tree, interfaces, and API contracts before coding. |
| `PERSONA` | `"you are a [role]"` | Adopts an authoritative senior specialist role with deep domain rigor. |
| `GHOST` / `/ghost` | `"/ghost"` | Strips all conversational filler, pleasantries, and robotic AI tone. |
| `REDTEAM` / `/redteam` | `"/redteam"` | Adversarially attacks the architecture to uncover edge-case failures. |
| `PREMORTEM` / `/premortem` | `"/premortem"` | Assumes the system failed post-launch and diagnoses root causes today. |
| `STEP BACK` | `"step back"` | Reframes confusing or complex tasks from first principles. |
| `RANK` | `"rank these"` | Prioritizes features/tasks by impact vs. implementation effort. |
| `RACI` | `"make this a RACI"` | Builds a RACI responsibility matrix for team execution. |
| `SOP` | `"turn into an SOP"` | Converts workflows into a repeatable Standard Operating Procedure. |
| `NEXT ACTION` | `"next action?"` | Delivers exactly ONE immediate next task instead of ten. |
| `ONE-PAGER` | `"one-pager"` | Produces an executive 1-page summary for leadership or jury heads. |
| `TL;DR` | `"tl;dr"` | Delivers the bottom-line conclusion first before supporting details. |
| `DIFF` | `"diff this"` | Formats all modifications strictly as unified git diffs. |
| `CONSTRAINTS` | `"given $X, Y days"` | Enforces strict real-world budget, timeline, and compute limits. |
| `VS` | `"X vs Y"` | Side-by-side comparison forcing a decisive engineering trade-off. |
| `TIGHTEN` | `"tighten this"` | Cuts fluff and condenses copy into high-impact bullet points. |
| `DEVIL'S ADVOCATE` | `"devil's advocate"` | Pressure-tests prevailing assumptions with strong counter-evidence. |
| `CLIENT VOICE` | `"read as the client"` | Reviews the pitch strictly from the sponsoring Ministry/client perspective. |
| `ELI5` | `"eli5"` | Explains complex technical mechanisms using simple real-world analogies. |
| `SKEPTIC` / `/skeptic` | `"/skeptic"` | Interrogates the underlying premise of the question before answering. |
| `NO YAP` / `/noyap` | `"/noyap"` | Skips all small talk; outputs direct code or commands immediately. |
| `5 WHYS` | `"5 whys"` | Drills down five levels to uncover the true root cause of a failure. |
| `FLIP IT` | `"flip it"` | Inverts the problem and approaches the solution from the opposite direction. |
| `PROVE IT` | `"prove it"` | Backs all claims with empirical numbers, benchmarks, and citations. |
| `WORST CASE` | `"worst case?"` | Performs a rapid worst-case scenario risk gut-check. |
