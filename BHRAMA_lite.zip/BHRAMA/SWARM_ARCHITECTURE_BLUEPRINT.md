# Antigravity 2.0 • Advanced Agentic Engineering
# Level Up Antigravity Like A Pro
**The Definitive Multi-Agent Architecture, Skill Harness, and Master System Prompt for Supercharging Gemini 3.7 Flash High in the Antigravity IDE**

---

## Executive Overview & Capability Stack

Transform your AI coding assistant from a basic chatbot into an autonomous, multi-role software engineering swarm. By integrating reverse-engineered workflows from 14 industry-defining repositories (GStack, Ruflo, Claude Council, Strix, Vercel Web Guidelines, 21st, Headroom, and Project Brain), this blueprint equips your Antigravity IDE with:

- **Multi-Role Swarm Deliberation**: Automated planning via CEO, Principal Architect, Security, and QA roles.
- **Anti-Slop Design & 34 Production Pages**: Bespoke UI/UX, DESIGN.md protocol, and zero-missing-page audits.
- **Zero-Trust Security Enclave**: Strict backend authentication with zero client-side secret exposure + Strix pentesting.
- **Persistent Memory & Headroom Compression**: Cross-session `.brain/` architecture with 60–90% token reduction.
- **25 Rapid Prompt Modifiers**: Single-word execution triggers (SCAFFOLD, REDTEAM, PREMORTEM, DIFF, NO YAP).
- **One Master Copy-Paste Prompt**: A universal bootstrap prompt to configure any fresh workspace in seconds.

---

## Capability Layers

| Layer | Integrated Frameworks | Core Engineering Function |
| :--- | :--- | :--- |
| **1. Planning** | `garrytan/gstack` + `ruvnet/ruflo` | Role decomposition, swarm topology, and task graph generation. |
| **2. Council** | `hex/claude-council` | Multi-perspective deliberation, trade-off analysis, and jury defense. |
| **3. Deep Brain** | Gemini 3.7 Flash (High) | Deep reasoning, architectural decisions, and implementation plans. |
| **4. Execution** | `claude-code-setup` + `21st` + `taste-skill` | Explore ➔ Plan ➔ Code ➔ Commit, modern UI, and 34-page audit. |
| **5. Memory** | `ethan-ys/project-brain` + `headroom` | Persistent `.brain/` state and 60–90% token compression. |
| **6. Security** | `usestrix/strix` + `vercel-labs guidelines` | Interactive pentesting, backend auth enclave, and WCAG UI audit. |
| **7. Observer** | `rebelytics/one-skill-to-rule-them-all` | Self-improving task observer capturing user corrections. |

---

## Section 1: The 6-Stage Swarm Execution Architecture

Standard AI assistants jump directly into coding, generating shallow solutions with missing edge-case handling, unauthenticated frontend endpoints, and generic styles. The Pro Antigravity Architecture enforces a disciplined, multi-stage engineering pipeline:

### STAGE 1: Ingestion & Compression
- **Primary Engine**: Headroom + Ruflo
- **Operational Workflow & Responsibilities**: Raw problem statements, government docs, and API specs pass through `headroom-context-compression` to eliminate boilerplate tokens (60–90% reduction). `ruflo` builds a decentralized task graph.

### STAGE 2: Multi-Role Council
- **Primary Engine**: GStack + Claude Council
- **Operational Workflow & Responsibilities**: The virtual council deliberates:
  - **CEO**: Value prop & 10x USP
  - **Architect**: Microservices & data flow
  - **Security Lead**: Zero-trust auth
  - **QA Lead**: Edge-case failures
  - Probes with `REDTEAM` and `PREMORTEM` checks.

### STAGE 3: Deep Synthesis
- **Primary Engine**: Gemini 3.7 Flash High
- **Operational Workflow & Responsibilities**: Evaluates council trade-offs, finalizes the System Architecture, generates `implementation_plan.md`, and produces `DESIGN.md` (color tokens, typography, 8pt grid).

### STAGE 4: High-Velocity Code
- **Primary Engine**: Claude-Code-Setup + 21st
- **Operational Workflow & Responsibilities**: Executes the **Explore ➔ Plan ➔ Code ➔ Commit** loop. Builds UI using `21st-components` (Radix/Tailwind) and `taste-design-system`. Strictly enforces Backend Authentication (zero client secrets).

### STAGE 5: Dual Quality Audit
- **Primary Engine**: Vercel Guidelines + Strix
- **Operational Workflow & Responsibilities**: `web-design-guidelines` inspects UI for WCAG contrast and responsive breakpoints in `file:line` format. `playwright-cli` runs headless tests. Asks *"Ready for Strix Pentest?"* before running dynamic vulnerability scans.

### STAGE 6: Persistence & Learning
- **Primary Engine**: Project Brain + Task Observer
- **Operational Workflow & Responsibilities**: `gemini-project-brain` writes session context to `.brain/MAP.md` and `STATUS.md`. `one-skill-to-rule-them-all` captures user feedback to permanently refine agent heuristics.

---

## Section 2: Official Repository & Skill Registry

| Skill Name | Official GitHub URL | Reverse-Engineered Purpose |
| :--- | :--- | :--- |
| **taste-skill** | https://github.com/leonxlnx/taste-skill | Anti-slop frontend engineering, bespoke typography pairings, and micro-animations. |
| **21st** | https://github.com/serafimcloud/21st | Registry for modern React, Tailwind CSS, and Radix UI components (cards, command bars). |
| **awesome-design-md** | https://github.com/voltagent/awesome-design-md | DESIGN.md protocol generator for enforcing spatial rules, color tokens, and font scales. |
| **claude-image-generation** | https://github.com/hex/claude-image-generation | High-fidelity prompt synthesizer for UI mockups, vector blueprints, and domain assets. |
| **playwright-cli** | https://github.com/microsoft/playwright-cli | End-to-end browser automation, visual regression testing, and multi-viewport snapshots. |
| **headroom** | https://github.com/headroomlabs-ai/headroom | Context compression proxy reducing JSON, log, and RAG tokens by 60–90%. |
| **project-brain** | https://github.com/ethan-ys/project-brain | Cross-session persistent memory via `.brain/` (`MAP.md`, `STATUS.md`, `HANDOFF.md`). |
| **gstack** | https://github.com/garrytan/gstack | Opinionated virtual team stack (CEO, Designer, Engineering Manager, QA Lead). |
| **ruflo** | https://github.com/ruvnet/ruflo | Agent meta-harness for orchestrating multi-agent swarms and adaptive memory. |
| **claude-council** | https://github.com/hex/claude-council | Multi-model deliberation framework for side-by-side architecture cross-checking. |
| **strix** | https://github.com/usestrix/strix | Autonomous penetration testing agent for dynamic exploit detection and fix generation. |
| **web-design-guidelines** | https://github.com/vercel-labs/agent-skills | Vercel Web Interface Guidelines audit tool reporting WCAG issues in `file:line` format. |
| **claude-code-setup** | https://github.com/anthropics/claude-plugins-official | Explore ➔ Plan ➔ Code ➔ Commit CLI execution loop and project `/init` harness. |
| **one-skill-to-rule-them-all** | https://github.com/rebelytics/one-skill-to-rule-them-all | Task Observer meta-skill monitoring sessions and refining heuristics automatically. |
