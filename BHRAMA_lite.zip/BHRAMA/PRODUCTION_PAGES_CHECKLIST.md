# Section 3: The 34 Production-Grade Pages & UX States Checklist
*Reference: High-Value Production-Grade Pages People Often Forget*

---

## 01. Legal (15 Pages)
> **Why Teams Fail Without It**: Auditors, enterprise buyers, and ministry evaluators inspect these first. Missing legal pages create immediate compliance and liability rejection.

- [ ] **Privacy Policy** (DPDP Act 2023 & GDPR compliant)
- [ ] **Terms of Service**
- [ ] **Cookie Policy**
- [ ] **Cookie Preferences** (Active toggles)
- [ ] **Refund Policy**
- [ ] **Cancellation Policy**
- [ ] **Shipping Policy**
- [ ] **Return / Exchange Policy**
- [ ] **Disclaimer**
- [ ] **Accessibility Statement** (WCAG)
- [ ] **Data Processing Agreement (DPA)**
- [ ] **Acceptable Use Policy**
- [ ] **Security Policy**
- [ ] **Responsible Disclosure**
- [ ] **Community Guidelines**

---

## 02. Customer Lifecycle (16 Pages)
> **Why Teams Fail Without It**: These screens handle 90% of real user traffic. Missing payment failed or session expired screens cause silent user churn.

- [ ] **Login**
- [ ] **Register / Sign Up**
- [ ] **Email Verification**
- [ ] **Forgot Password**
- [ ] **Reset Password**
- [ ] **Onboarding Wizard / Stepper**
- [ ] **Account Settings & Profile**
- [ ] **Billing Dashboard & Invoices**
- [ ] **Upgrade Tier**
- [ ] **Downgrade Tier**
- [ ] **Cancel Subscription** (Retention flow)
- [ ] **Payment Success**
- [ ] **Payment Failed**
- [ ] **Payment Pending**
- [ ] **Support Desk**
- [ ] **Help Center / Knowledge Base**

---

## 03. UX States & Resilience (10 States)
> **Why Teams Fail Without It**: Designing only the "happy path" leaves users facing blank browser errors during network drops or expired tokens.

- [ ] **404 Not Found** (With search & home action)
- [ ] **403 Forbidden / Unauthorized**
- [ ] **500 Internal Server Error**
- [ ] **Maintenance Mode**
- [ ] **Offline Mode** (PWA Background Sync)
- [ ] **Empty State** (No data with CTA)
- [ ] **No Search Results**
- [ ] **Skeleton Loading States**
- [ ] **Error Toast / Modal States**
- [ ] **Session Expired** (Preserving unsaved form input)
