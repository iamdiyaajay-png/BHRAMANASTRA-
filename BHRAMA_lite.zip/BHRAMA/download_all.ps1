$ErrorActionPreference = "Continue"

$repos = @(
    @{ Name = "taste-skill"; Owner = "leonxlnx"; Repo = "taste-skill" },
    @{ Name = "21st"; Owner = "serafimcloud"; Repo = "21st" },
    @{ Name = "awesome-design-md"; Owner = "voltagent"; Repo = "awesome-design-md" },
    @{ Name = "claude-image-generation"; Owner = "hex"; Repo = "claude-image-generation" },
    @{ Name = "playwright-cli"; Owner = "microsoft"; Repo = "playwright-cli" },
    @{ Name = "headroom"; Owner = "headroomlabs-ai"; Repo = "headroom" },
    @{ Name = "project-brain"; Owner = "ethan-ys"; Repo = "project-brain" },
    @{ Name = "gstack"; Owner = "garrytan"; Repo = "gstack" },
    @{ Name = "ruflo"; Owner = "ruvnet"; Repo = "ruflo" },
    @{ Name = "claude-council"; Owner = "hex"; Repo = "claude-council" },
    @{ Name = "strix"; Owner = "usestrix"; Repo = "strix" },
    @{ Name = "web-design-guidelines"; Owner = "vercel-labs"; Repo = "agent-skills" },
    @{ Name = "claude-code-setup"; Owner = "anthropics"; Repo = "claude-plugins-official" },
    @{ Name = "one-skill-to-rule-them-all"; Owner = "rebelytics"; Repo = "one-skill-to-rule-them-all" }
)

$targetDir = Join-Path $PSScriptRoot "repositories"
if (-not (Test-Path $targetDir)) {
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
}

$tempDir = Join-Path $PSScriptRoot ".temp_download"
if (-not (Test-Path $tempDir)) {
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
}

$successCount = 0
$failCount = 0

for ($i = 0; $i -lt $repos.Count; $i++) {
    $item = $repos[$i]
    $num = $i + 1
    Write-Host "`n========================================"
    Write-Host "[$num/$($repos.Count)] Processing $($item.Name) ($($item.Owner)/$($item.Repo))..."
    $finalRepoDir = Join-Path $targetDir $item.Name

    if (Test-Path $finalRepoDir) {
        $count = (Get-ChildItem -Path $finalRepoDir -Force).Count
        if ($count -gt 0) {
            Write-Host "  Already downloaded and extracted ($count items). Skipping."
            $successCount++
            continue
        }
    }

    $zipPath = Join-Path $tempDir "$($item.Name).zip"
    if (Test-Path $zipPath) { Remove-Item $zipPath -Force }

    $branches = @("main", "master")
    $downloaded = $false

    foreach ($branch in $branches) {
        $url = "https://codeload.github.com/$($item.Owner)/$($item.Repo)/zip/refs/heads/$branch"
        Write-Host "  Attempting download from branch '$branch'..."
        & curl.exe -L -s --fail -o "$zipPath" "$url"
        if ($LASTEXITCODE -eq 0 -and (Test-Path $zipPath) -and ((Get-Item $zipPath).Length -gt 100)) {
            $mb = [math]::Round((Get-Item $zipPath).Length / 1MB, 2)
            Write-Host "  Successfully downloaded branch '$branch' ($mb MB)"
            $downloaded = $true
            break
        }
        if (Test-Path $zipPath) { Remove-Item $zipPath -Force -ErrorAction SilentlyContinue }
    }

    if (-not $downloaded) {
        Write-Host "  Attempting fallback download via HEAD.zip..."
        $url = "https://github.com/$($item.Owner)/$($item.Repo)/archive/HEAD.zip"
        & curl.exe -L -s --fail -o "$zipPath" "$url"
        if ($LASTEXITCODE -eq 0 -and (Test-Path $zipPath) -and ((Get-Item $zipPath).Length -gt 100)) {
            $mb = [math]::Round((Get-Item $zipPath).Length / 1MB, 2)
            Write-Host "  Successfully downloaded HEAD.zip ($mb MB)"
            $downloaded = $true
        }
    }

    if ($downloaded) {
        Write-Host "  Extracting archive..."
        $extractFolder = Join-Path $tempDir "extract_$($item.Name)"
        if (Test-Path $extractFolder) { Remove-Item $extractFolder -Recurse -Force }
        New-Item -ItemType Directory -Path $extractFolder -Force | Out-Null

        & tar.exe -xf "$zipPath" -C "$extractFolder"
        
        $subDirs = Get-ChildItem -Path $extractFolder -Directory
        if (-not (Test-Path $finalRepoDir)) {
            New-Item -ItemType Directory -Path $finalRepoDir -Force | Out-Null
        }

        if ($subDirs.Count -eq 1) {
            Get-ChildItem -Path $subDirs[0].FullName -Force | Move-Item -Destination $finalRepoDir -Force
        } else {
            Get-ChildItem -Path $extractFolder -Force | Move-Item -Destination $finalRepoDir -Force
        }

        Remove-Item $extractFolder -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
        Write-Host "  Successfully extracted to: $finalRepoDir"
        $successCount++
    } else {
        Write-Host "  FAILED to download $($item.Name) from $($item.Owner)/$($item.Repo)"
        $failCount++
    }
}

Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue

Write-Host "`n========================================"
Write-Host "DOWNLOAD COMPLETE: $successCount succeeded, $failCount failed."
Write-Host "========================================"
