# Level Up Antigravity Like A Pro
### Antigravity 2.0 • Advanced Agentic Engineering Architecture

This workspace contains the complete suite of reverse-engineered repositories, multi-agent frameworks, operational protocols, and bootstrap templates defined in the **Level Up Antigravity Like A Pro** blueprint.

---

## Workspace Structure

```
NASA/
├── repositories/                  # All 14 official repositories & skills
│   ├── taste-skill/               # Anti-slop frontend engineering & design taste
│   ├── 21st/                      # Modern React, Tailwind, and Radix UI registry
│   ├── awesome-design-md/         # DESIGN.md protocol generator
│   ├── claude-image-generation/   # Prompt synthesizer for mockups & vector assets
│   ├── playwright-cli/            # Headless browser automation & visual regression
│   ├── headroom/                  # Context compression proxy (60-90% token reduction)
│   ├── project-brain/             # Persistent cross-session memory (.brain/ architecture)
│   ├── gstack/                    # Garry Tan's virtual team roles (CEO, Designer, EM, QA)
│   ├── ruflo/                     # Multi-agent swarm orchestration & adaptive memory
│   ├── claude-council/            # Multi-model deliberation framework
│   ├── strix/                     # Autonomous security pentesting agent
│   ├── web-design-guidelines/     # Vercel WCAG & responsive UI audit tool
│   ├── claude-code-setup/         # Anthropic official plugins & Explore-Plan-Code-Commit loop
│   └── one-skill-to-rule-them-all/# Continuous task observer & self-refining heuristics
├── MASTER_BOOTSTRAP_PROMPT.md     # Copy-paste master prompt to initialize any workspace
├── PRODUCTION_PAGES_CHECKLIST.md  # 34 production-grade pages & UX resilience states checklist
├── PROMPT_TRIGGERS_CHEAT_SHEET.md # 25 rapid execution modifier prompt triggers
├── SECURITY_AND_PENTEST_PROTOCOL.md # Zero-trust backend auth & Strix pentest protocol
└── SWARM_ARCHITECTURE_BLUEPRINT.md# 6-stage swarm execution architecture & stack specification
```

---

## Core Architecture Highlights

1. **6-Stage Swarm Execution Architecture**:
   - `STAGE 1`: Ingestion & Context Compression (Headroom + Ruflo)
   - `STAGE 2`: Multi-Role Deliberation Council (GStack + Claude Council)
   - `STAGE 3`: Deep Synthesis & Architecture (Gemini 3.7 Flash High)
   - `STAGE 4`: High-Velocity Code Execution (Claude-Code-Setup + 21st + Taste)
   - `STAGE 5`: Dual Quality Audit & Pentest (Vercel Guidelines + Playwright + Strix)
   - `STAGE 6`: Persistence & Self-Improving Memory (Project Brain + Task Observer)

2. **Zero-Trust Backend Enclave**:
   - Strict separation: All auth, API keys, and database queries live strictly in backend routes.
   - Zero frontend token leakage.

3. **Production Completeness**:
   - 34-page audit: 15 Legal pages, 16 Customer Lifecycle screens, 10 Resilience/UX states.

---

## Getting the repositories

The `repositories/` folder (~480 MB of third-party GitHub projects) is not included in this repo because of GitHub's file size limits. To download all 14 of them, run this from the project root in PowerShell:

```powershell
./download_all.ps1
```
